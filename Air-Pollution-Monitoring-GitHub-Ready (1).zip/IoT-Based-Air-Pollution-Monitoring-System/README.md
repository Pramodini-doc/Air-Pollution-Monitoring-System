# IoT-Based Air Pollution Monitoring System Using Arduino

## Overview
A mini-project synopsis describing an IoT-based system for monitoring air quality using sensors and an Arduino board. The system is intended to display air-quality readings in PPM on an LCD and a webpage, and provide alerts when pollution levels cross specified thresholds.

## Components Listed in the Synopsis
- MQ135 gas sensor
- Arduino Uno
- ESP8266 Wi-Fi module
- 16x2 LCD
- Breadboard
- 10k potentiometer
- 1k ohm resistor
- 220 ohm resistor
- Buzzer

## Behaviour Described in the Synopsis
- Below 1000 PPM: display “Fresh air”
- Above 1000 PPM: sound the buzzer and display “Poor Air, Open Windows”
- Above 2000 PPM: keep the buzzer beeping and display “Danger! Move to fresh Air”

The synopsis describes sending sensor readings to a web server so the readings can be viewed online.

## Project Documentation
The original project synopsis is included in this repository package.

## Source Code
Arduino firmware, circuit diagrams, and web-server source files were not included in the uploaded material. Add the actual implementation files before presenting this repository as a complete runnable project.
